﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai22 : Form
    {
        public Bai22()
        {
            InitializeComponent();
        }

        private void btnCapNhatNV_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvi in listNhanVien.SelectedItems)
            {
                lvi.SubItems[0].Text = txtTenNV.Text;
                lvi.SubItems[1].Text = txtChucVuNV.Text;
                lvi.SubItems[2].Text = txtHeSoLuongNV.Text;
                lvi.SubItems[3].Text = txtLuongCBNV.Text;
            }
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            if (txtLuongCBNV.Text != "" && txtTenNV.Text != "" && txtHeSoLuongNV.Text != "" && txtChucVuNV.Text != "")
            {
                ListViewItem LVItem = new ListViewItem(txtTenNV.Text);
                ListViewItem.ListViewSubItem LVSItemCV = new
                ListViewItem.ListViewSubItem(LVItem,
                txtChucVuNV.Text);
                ListViewItem.ListViewSubItem LVSItemHSL = new
                ListViewItem.ListViewSubItem(LVItem,
                txtHeSoLuongNV.Text);
                ListViewItem.ListViewSubItem LVSItemLCB = new
                ListViewItem.ListViewSubItem(LVItem,
                txtLuongCBNV.Text);
                LVItem.SubItems.Add(LVSItemCV);
                LVItem.SubItems.Add(LVSItemHSL);
                LVItem.SubItems.Add(LVSItemLCB);
                listNhanVien.Items.Add(LVItem);
                txtLuongCBNV.Text = "";
                txtTenNV.Text = "";
                txtHeSoLuongNV.Text = "";
                txtChucVuNV.Text = "";
            }
            else
                MessageBox.Show("Phải nhập đầy đủ thông tin nhân viên");
        }

        private void btnXoaNV_Click(object sender, EventArgs e)
        {
            if (listNhanVien.SelectedIndices.Count > 0)
            {
                listNhanVien.Items.RemoveAt(listNhanVien.FocusedItem.Index);
            }
            else
                MessageBox.Show("Phải chọn nhân viên muốn ");
        }

        private void listNhanVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem lvi in listNhanVien.SelectedItems)
            {
                txtTenNV.Text = lvi.SubItems[0].Text;
                txtChucVuNV.Text = lvi.SubItems[1].Text;
                txtHeSoLuongNV.Text = lvi.SubItems[2].Text;
                txtLuongCBNV.Text = lvi.SubItems[3].Text;
            }
        }

        private void btnCapNhatGV_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvilvi in listGiaoVien.SelectedItems)
            {
                lvilvi.SubItems[0].Text = txtTenGV.Text;
                lvilvi.SubItems[1].Text = txtHocVi.Text;
                lvilvi.SubItems[2].Text = txtTienDayMotTiet.Text;
                lvilvi.SubItems[3].Text = txtSoTietDay.Text;
            }
        }

        private void btnThemGV_Click(object sender, EventArgs e)
        {
            if (txtTienDayMotTiet.Text != "" && txtTenGV.Text != "" && txtSoTietDay.Text != "" && txtHocVi.Text != "")
            {
                ListViewItem LVItemLVItem = new ListViewItem(txtTenGV.Text);
                ListViewItem.ListViewSubItem LVSItemCVLVSItemCV = new
                ListViewItem.ListViewSubItem(LVItemLVItem,
                txtHocVi.Text);
                ListViewItem.ListViewSubItem LVSItemHSLLVSItemHSL = new
                ListViewItem.ListViewSubItem(LVItemLVItem,
                txtSoTietDay.Text);
                ListViewItem.ListViewSubItem LVSItemLCBLVSItemLCB = new
                ListViewItem.ListViewSubItem(LVItemLVItem,
                txtTienDayMotTiet.Text);
                LVItemLVItem.SubItems.Add(LVSItemCVLVSItemCV);
                LVItemLVItem.SubItems.Add(LVSItemHSLLVSItemHSL);
                LVItemLVItem.SubItems.Add(LVSItemLCBLVSItemLCB);
                listGiaoVien.Items.Add(LVItemLVItem);
                txtTienDayMotTiet.Text = "";
                txtTenGV.Text = "";
                txtSoTietDay.Text = "";
                txtHocVi.Text = "";
            }
            else
                MessageBox.Show("Phải nhập đầy đủ thông tin giáo viên");
        }

        private void btnXoaGV_Click(object sender, EventArgs e)
        {
            if (listGiaoVien.SelectedIndices.Count > 0)
            {
                listGiaoVien.Items.RemoveAt(listGiaoVien.FocusedItem.Index);
            }
            else
                MessageBox.Show("Phải chọn giáo viên muốn ");
        }

        private void listGiaoVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem lvilvi in listGiaoVien.SelectedItems)
            {
                txtTenGV.Text = lvilvi.SubItems[0].Text;
                txtHocVi.Text = lvilvi.SubItems[1].Text;
                txtSoTietDay.Text = lvilvi.SubItems[2].Text;
                txtTienDayMotTiet.Text = lvilvi.SubItems[3].Text;
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
