﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai15 : Form
    {
        public Bai15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtA.Text, out double a) && double.TryParse(txtB.Text, out double b))
            {
                string selectedPhepTinh = cbPhepTinh.SelectedItem.ToString();

                double result = 0.0;

                switch (selectedPhepTinh)
                {
                    case "+":
                        result = a + b;
                        break;
                    case "-":
                        result = a - b;
                        break;
                    case "*":
                        result = a * b;
                        break;
                    case "/":
                        if (b != 0)
                            result = a / b;
                        else
                            MessageBox.Show("Lỗi: Không thể chia cho 0.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
                txtKQ.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Lỗi: Vui lòng nhập giá trị hợp lệ cho A và B.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
