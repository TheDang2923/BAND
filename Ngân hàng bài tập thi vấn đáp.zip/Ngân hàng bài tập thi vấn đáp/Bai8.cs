﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai8 : Form
    {
        public Bai8()
        {
            InitializeComponent();
        }
        private void UpdateTextBoxBackgroundColor()
        {
            int red = hsbRed.Value;
            int green = hsbGreen.Value;
            int blue = hsbBlue.Value;

            textBox1.BackColor = Color.FromArgb(red, green, blue);
        }

        private void hsbRed_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateTextBoxBackgroundColor();
            txtRed.Text = "" + hsbRed.Value;
        }

        private void hsbGreen_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateTextBoxBackgroundColor();
            txtGreen.Text = "" + hsbGreen.Value;
        }

        private void hsbBlue_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateTextBoxBackgroundColor();
            txtBlue.Text = "" + hsbBlue.Value;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
