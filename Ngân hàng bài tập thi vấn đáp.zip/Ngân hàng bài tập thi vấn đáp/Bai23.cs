﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai23 : Form
    {
        public Bai23()
        {
            InitializeComponent();
        }

        private void Bai23_Load(object sender, EventArgs e)
        {
            myWebsite.Navigate("www.google.com");
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            ListViewItem lvi = new ListViewItem(txtLink.Text);
            listLinkWebsite.Items.Add(lvi);
            txtLink.Text = "";
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            listLinkWebsite.FocusedItem.Text = txtLink.Text;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int i = listLinkWebsite.FocusedItem.Index;
            listLinkWebsite.Items.RemoveAt(i);
            txtLink.Text = "";
            myWebsite.Navigate("www.google.com");
        }

        private void listLinkWebsite_MouseClick(object sender, MouseEventArgs e)
        {
            txtLink.Text = listLinkWebsite.FocusedItem.Text;
            if (e.Button == MouseButtons.Left)
                myWebsite.Navigate(listLinkWebsite.FocusedItem.Text);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
