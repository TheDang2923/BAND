﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai24
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHienThi = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnChonMau = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.radMauChu = new System.Windows.Forms.RadioButton();
            this.radMauNen = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHienThi
            // 
            this.lblHienThi.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHienThi.Location = new System.Drawing.Point(0, 9);
            this.lblHienThi.Name = "lblHienThi";
            this.lblHienThi.Size = new System.Drawing.Size(626, 130);
            this.lblHienThi.TabIndex = 0;
            this.lblHienThi.Text = "Khoa Công nghệ thông tin";
            this.lblHienThi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Controls.Add(this.btnChonMau);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 142);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(626, 130);
            this.panel1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radMauNen);
            this.groupBox1.Controls.Add(this.radMauChu);
            this.groupBox1.Location = new System.Drawing.Point(28, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(322, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn màu chữ hoặc màu nền";
            // 
            // btnChonMau
            // 
            this.btnChonMau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChonMau.Location = new System.Drawing.Point(397, 23);
            this.btnChonMau.Name = "btnChonMau";
            this.btnChonMau.Size = new System.Drawing.Size(172, 41);
            this.btnChonMau.TabIndex = 1;
            this.btnChonMau.Text = "Chọn màu";
            this.btnChonMau.UseVisualStyleBackColor = true;
            this.btnChonMau.Click += new System.EventHandler(this.btnChonMau_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Location = new System.Drawing.Point(397, 70);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(172, 41);
            this.btnThoat.TabIndex = 2;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // radMauChu
            // 
            this.radMauChu.AutoSize = true;
            this.radMauChu.Location = new System.Drawing.Point(47, 35);
            this.radMauChu.Name = "radMauChu";
            this.radMauChu.Size = new System.Drawing.Size(117, 32);
            this.radMauChu.TabIndex = 0;
            this.radMauChu.TabStop = true;
            this.radMauChu.Text = "Màu chữ";
            this.radMauChu.UseVisualStyleBackColor = true;
            // 
            // radMauNen
            // 
            this.radMauNen.AutoSize = true;
            this.radMauNen.Location = new System.Drawing.Point(47, 67);
            this.radMauNen.Name = "radMauNen";
            this.radMauNen.Size = new System.Drawing.Size(116, 32);
            this.radMauNen.TabIndex = 1;
            this.radMauNen.TabStop = true;
            this.radMauNen.Text = "Màu nền";
            this.radMauNen.UseVisualStyleBackColor = true;
            // 
            // Bai24
            // 
            this.AcceptButton = this.btnChonMau;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(626, 272);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblHienThi);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai24";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài tập";
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblHienThi;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnChonMau;
        private System.Windows.Forms.RadioButton radMauNen;
        private System.Windows.Forms.RadioButton radMauChu;
    }
}