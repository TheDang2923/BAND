﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai20
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTieude = new System.Windows.Forms.TextBox();
            this.btnCong = new System.Windows.Forms.Button();
            this.btnTru = new System.Windows.Forms.Button();
            this.btnThemnodegoc = new System.Windows.Forms.Button();
            this.btnThemnodedangchon = new System.Windows.Forms.Button();
            this.btnXoatatcanode = new System.Windows.Forms.Button();
            this.btnXoanodedangchon = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "TreeView";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(367, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tiêu đề node:";
            // 
            // txtTieude
            // 
            this.txtTieude.Location = new System.Drawing.Point(511, 45);
            this.txtTieude.Name = "txtTieude";
            this.txtTieude.Size = new System.Drawing.Size(301, 36);
            this.txtTieude.TabIndex = 0;
            // 
            // btnCong
            // 
            this.btnCong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCong.Location = new System.Drawing.Point(253, 297);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(51, 40);
            this.btnCong.TabIndex = 6;
            this.btnCong.Text = "+";
            this.btnCong.UseVisualStyleBackColor = true;
            this.btnCong.Click += new System.EventHandler(this.btnCong_Click);
            // 
            // btnTru
            // 
            this.btnTru.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTru.Location = new System.Drawing.Point(310, 297);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(51, 40);
            this.btnTru.TabIndex = 7;
            this.btnTru.Text = "-";
            this.btnTru.UseVisualStyleBackColor = true;
            this.btnTru.Click += new System.EventHandler(this.btnTru_Click);
            // 
            // btnThemnodegoc
            // 
            this.btnThemnodegoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemnodegoc.Location = new System.Drawing.Point(511, 87);
            this.btnThemnodegoc.Name = "btnThemnodegoc";
            this.btnThemnodegoc.Size = new System.Drawing.Size(301, 36);
            this.btnThemnodegoc.TabIndex = 1;
            this.btnThemnodegoc.Text = "Thêm node gốc";
            this.btnThemnodegoc.UseVisualStyleBackColor = true;
            this.btnThemnodegoc.Click += new System.EventHandler(this.btnThemnodegoc_Click);
            // 
            // btnThemnodedangchon
            // 
            this.btnThemnodedangchon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemnodedangchon.Location = new System.Drawing.Point(511, 129);
            this.btnThemnodedangchon.Name = "btnThemnodedangchon";
            this.btnThemnodedangchon.Size = new System.Drawing.Size(301, 36);
            this.btnThemnodedangchon.TabIndex = 2;
            this.btnThemnodedangchon.Text = "Thêm node con tại vị trí chọn";
            this.btnThemnodedangchon.UseVisualStyleBackColor = true;
            this.btnThemnodedangchon.Click += new System.EventHandler(this.btnThemnodedangchon_Click);
            // 
            // btnXoatatcanode
            // 
            this.btnXoatatcanode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoatatcanode.Location = new System.Drawing.Point(511, 171);
            this.btnXoatatcanode.Name = "btnXoatatcanode";
            this.btnXoatatcanode.Size = new System.Drawing.Size(301, 36);
            this.btnXoatatcanode.TabIndex = 3;
            this.btnXoatatcanode.Text = "Xóa tất cả các node";
            this.btnXoatatcanode.UseVisualStyleBackColor = true;
            this.btnXoatatcanode.Click += new System.EventHandler(this.btnXoatatcanode_Click);
            // 
            // btnXoanodedangchon
            // 
            this.btnXoanodedangchon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoanodedangchon.Location = new System.Drawing.Point(511, 213);
            this.btnXoanodedangchon.Name = "btnXoanodedangchon";
            this.btnXoanodedangchon.Size = new System.Drawing.Size(301, 36);
            this.btnXoanodedangchon.TabIndex = 4;
            this.btnXoanodedangchon.Text = "Xóa node đang chọn";
            this.btnXoanodedangchon.UseVisualStyleBackColor = true;
            this.btnXoanodedangchon.Click += new System.EventHandler(this.btnXoanodedangchon_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Location = new System.Drawing.Point(511, 255);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(301, 36);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(37, 45);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(324, 246);
            this.treeView1.TabIndex = 8;
            // 
            // Bai20
            // 
            this.AcceptButton = this.btnThemnodegoc;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(845, 353);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXoanodedangchon);
            this.Controls.Add(this.btnXoatatcanode);
            this.Controls.Add(this.btnThemnodedangchon);
            this.Controls.Add(this.btnThemnodegoc);
            this.Controls.Add(this.btnTru);
            this.Controls.Add(this.btnCong);
            this.Controls.Add(this.txtTieude);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai20";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Node";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTieude;
        private System.Windows.Forms.Button btnCong;
        private System.Windows.Forms.Button btnTru;
        private System.Windows.Forms.Button btnThemnodegoc;
        private System.Windows.Forms.Button btnThemnodedangchon;
        private System.Windows.Forms.Button btnXoatatcanode;
        private System.Windows.Forms.Button btnXoanodedangchon;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.TreeView treeView1;
    }
}