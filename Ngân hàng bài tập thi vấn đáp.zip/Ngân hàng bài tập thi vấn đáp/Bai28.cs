﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai28 : Form
    {
        public Bai28()
        {
            InitializeComponent();
        }

        private void btnNhapThongTin_Click(object sender, EventArgs e)
        {
            // Lấy thông tin từ người dùng
            string hoDem = txtHoDem.Text;
            string ten = txtTen.Text;
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            string ngonNgu = LayNgonNgu();

            // Hiển thị thông tin
            string thongTin = $"Họ đệm: {hoDem}\nTên: {ten}\nGiới tính: {gioiTinh}\nNgôn ngữ: {ngonNgu}";
            MessageBox.Show(thongTin, "Thông tin người dùng");
        }
        private string LayNgonNgu()
        {
            string ngonNgu = "";
            if (chkTiengAnh.Checked)
            {
                ngonNgu += "Tiếng Anh, ";
            }
            if (chkTiengTrung.Checked)
            {
                ngonNgu += "Tiếng Trung, ";
            }

            // Loại bỏ dấu phẩy cuối cùng nếu có
            if (!string.IsNullOrEmpty(ngonNgu))
            {
                ngonNgu = ngonNgu.TrimEnd(',', ' ');
            }

            return ngonNgu;
        }

        private void btnNhapLai_Click(object sender, EventArgs e)
        {
            // Xóa thông tin đã nhập
            txtHoDem.Clear();
            txtTen.Clear();
            radNam.Checked = false;
            radNu.Checked = false;
            chkTiengAnh.Checked = false;
            chkTiengTrung.Checked = false;
            listBox1.Items.Clear();
        }
    }
}
