﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }
        private int incorrectAttempts = 0;

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }

        private void chkHienThi_CheckedChanged(object sender, EventArgs e)
        {
            txtMatKhau.PasswordChar = chkHienThi.Checked ? '\0' : '*';
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string TaiKhoan = txtTen.Text;
            string MatKhau = txtMatKhau.Text;
            if (TaiKhoan == "admin" && MatKhau == "123456")
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                incorrectAttempts++;

                if (incorrectAttempts < 3)
                {
                    MessageBox.Show("Sai mật khẩu! Bạn đã nhập sai " + incorrectAttempts + " lần.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Bạn đã nhập sai quá 3 lần. Ứng dụng sẽ thoát.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Close(); // Close the application after 3 incorrect attempts
                }
            }
        }
    }
}
