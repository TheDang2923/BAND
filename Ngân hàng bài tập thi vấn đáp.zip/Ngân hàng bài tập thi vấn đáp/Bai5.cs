﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai5 : Form
    {
        public Bai5()
        {
            InitializeComponent();
        }
        private double CalculateSumS1(int n)
        {
            double sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += (2 * i - 1);
            }
            return sum;
        }

        private double CalculateSumS2(int n)
        {
            double sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += i * i;
            }
            return sum;
        }

        private double CalculateSumS3(int n)
        {
            double sum = 0;
            for (int i = 1; i <= n; i++)
            {
                sum += 1.0 / i;
            }
            return sum;
        }

        private double CalculateSumS4(int n)
        {
            double sum = 0;
            double factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
                sum += 1.0 / factorial;
            }
            return sum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(txtNhapN.Text, out n) && n > 0)
            {
                double result = 0;

                if (radioButton1.Checked)
                    result = CalculateSumS1(n);
                else if (radioButton2.Checked)
                    result = CalculateSumS2(n);
                else if (radioButton3.Checked)
                    result = CalculateSumS3(n);
                else if (radioButton4.Checked)
                    result = CalculateSumS4(n);

                txtKetQua.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên dương hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTinhTiep_Click(object sender, EventArgs e)
        {
            txtNhapN.Text = "";
            txtKetQua.Text = "";

            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
