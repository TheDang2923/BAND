﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai7 : Form
    {
        public Bai7()
        {
            InitializeComponent();
        }

        private void btnDangky_Click(object sender, EventArgs e)
        {
            string hoTen = txtHoTen.Text;
            string ngaySinhString = txtNgaySinh.Text;
            string diemTrungBinhString = txtDTB.Text;

            if (DateTime.TryParseExact(ngaySinhString, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime ngaySinh))
            {
                if (double.TryParse(diemTrungBinhString, out double diemTrungBinh))
                {
                    MessageBox.Show($"Đăng ký thành công!\nHọ tên: {hoTen}\nNgày sinh: {ngaySinh:dd/MM/yyyy}\nĐiểm trung bình: {diemTrungBinh}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    LoiDiemTB.SetError(txtDTB, "Nhập số");
                }
            }
            else
            {
                LoiNgaySinh.SetError(txtNgaySinh, "Ngày sinh dd/MM/yyyy");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
