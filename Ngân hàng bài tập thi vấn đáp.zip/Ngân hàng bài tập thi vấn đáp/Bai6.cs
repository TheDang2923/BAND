﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai6 : Form
    {
        public Bai6()
        {
            InitializeComponent();
        }

        private void lstBoxA_SelectedIndexChanged(object sender, EventArgs e)
        {
            string str = "";
            foreach (string item in lstBoxA.Items)
                str = str + item + "; ";
        }

        private void btnCN_Click(object sender, EventArgs e)
        {
            lstBoxA.Items.Add(txtAdd.Text);
            txtAdd.Focus();
            txtAdd.Clear();
        }

        private void btnXoaDauCuoi_Click(object sender, EventArgs e)
        {
            if (lstBoxA.Items.Count != 0)
            {
                lstBoxA.Items.RemoveAt(0);
                if (lstBoxA.Items.Count >= 1)
                {
                    lstBoxA.Items.RemoveAt(lstBoxA.Items.Count - 1);
                }
            }
            else
            {
                MessageBox.Show("Không còn phần tử nào.", "Thông báo");
            }
        }

        private void btnXoaDangChon_Click(object sender, EventArgs e)
        {
            if (lstBoxA.SelectedIndex != -1)
            {
                while (lstBoxA.SelectedItems.Count > 0)
                {
                    lstBoxA.Items.Remove(lstBoxA.SelectedItems[0]);
                }
            }
            else
            {
                MessageBox.Show("Chưa chọn phần tử cần xóa.", "Thông báo");
            }
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            double S = 0;
            for (int i = 0; i < lstBoxA.Items.Count; i++)
            {
                S += double.Parse(lstBoxA.Items[i].ToString());
            }
            MessageBox.Show("Tổng của các phần tử là: " + S, "Thông báo");
        }

        private void btnTang2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstBoxA.Items.Count; i++)
            {
                lstBoxA.Items[i] = int.Parse(lstBoxA.Items[i].ToString()) + 2;
            }
        }

        private void btnBP_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstBoxA.Items.Count; i++)
            {
                lstBoxA.Items[i] = Math.Pow(int.Parse(lstBoxA.Items[i].ToString()), 2);
            }
        }

        private void btnSC_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstBoxA.Items.Count; i++)
            {
                if (double.Parse(lstBoxA.Items[i].ToString()) % 2 == 0)
                {
                    lstBoxA.SetSelected(i, true);
                }
            }
        }

        private void btnSL_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstBoxA.Items.Count; i++)
            {
                if (double.Parse(lstBoxA.Items[i].ToString()) % 2 != 0)
                {
                    lstBoxA.SetSelected(i, true);
                }
            }
        }

        private void btnKT_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
