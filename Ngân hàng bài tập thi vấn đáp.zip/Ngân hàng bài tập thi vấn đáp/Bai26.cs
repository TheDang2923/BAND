﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai26 : Form
    {
        public Bai26()
        {
            InitializeComponent();
        }
        class PhanSo
        {
            private int tu, mau;
            public PhanSo() { }
            public PhanSo(int tu, int mau)
            {
                this.tu = tu;
                this.mau = mau;
            }
            public void setTu(int tu)
            {
                this.tu = tu;
            }
            public void setMau(int mau)
            {
                this.mau = mau;
            }
            public int getTu()
            {
                return tu;
            }
            public int getMau()
            {
                return mau;
            }
            public int UCLN(int a, int b)
            {
                if (a < 0) a *= -1;
                if (b < 0) b *= -1;
                while (a != b)
                {
                    if (a > b) a -= b;
                    else b -= a;
                }
                return a;
            }
            public void RutGon()
            {
                int u = UCLN(this.tu, this.mau);
                this.tu /= u;
                this.mau /= u;
            }

            public static PhanSo operator +(PhanSo a, PhanSo b)
            {
                PhanSo c = new PhanSo();
                c.tu = a.tu * b.mau + a.mau * b.tu;
                c.mau = a.mau * b.mau;
                c.RutGon();
                return c;
            }
            public static PhanSo operator -(PhanSo a, PhanSo b)
            {
                PhanSo c = new PhanSo();
                c.tu = a.tu * b.mau - a.mau * b.tu;
                c.mau = a.mau * b.mau;
                c.RutGon();
                return c;
            }
            public static PhanSo operator *(PhanSo a, PhanSo b)
            {
                PhanSo c = new PhanSo();
                c.tu = a.tu * b.tu;
                c.mau = a.mau * b.mau;
                c.RutGon();
                return c;
            }
            public static PhanSo operator /(PhanSo a, PhanSo b)
            {
                PhanSo c = new PhanSo();
                c.tu = a.tu * b.mau;
                c.mau = a.mau * b.tu;
                c.RutGon();
                return c;
            }
        }

        private void btnTiepTuc_Click(object sender, EventArgs e)
        {
            txtTS1.ResetText();
            txtMS1.ResetText();
            txtTS2.ResetText();
            txtMS2.ResetText();
            txtKQTS.ResetText();
            txtKQMS.ResetText();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PhanSo a = new PhanSo(int.Parse(txtTS1.Text), int.Parse(txtMS1.Text));
            PhanSo b = new PhanSo(int.Parse(txtTS2.Text), int.Parse(txtMS2.Text));
            PhanSo c = a + b;
            PhanSo d = new PhanSo();
            if (a.getTu() / a.getMau() > b.getTu() / b.getMau()) d = a;
            else d = b;
            grKQ.Text = "Kết quả Cộng";
            txtKQTS.Text = c.getTu().ToString();
            txtKQMS.Text = c.getMau().ToString();
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            PhanSo a = new PhanSo(int.Parse(txtTS1.Text), int.Parse(txtMS1.Text));
            PhanSo b = new PhanSo(int.Parse(txtTS2.Text), int.Parse(txtMS2.Text));
            PhanSo c = a - b;
            PhanSo d = new PhanSo();
            if (a.getTu() / a.getMau() > b.getTu() / b.getMau()) d = a;
            else d = b;
            grKQ.Text = "Kết quả Trừ";
            txtKQTS.Text = c.getTu().ToString();
            txtKQMS.Text = c.getMau().ToString();
        }

        private void btnNhan_Click(object sender, EventArgs e)
        {
            PhanSo a = new PhanSo(int.Parse(txtTS1.Text), int.Parse(txtMS1.Text));
            PhanSo b = new PhanSo(int.Parse(txtTS2.Text), int.Parse(txtMS2.Text));
            PhanSo c = a * b;
            PhanSo d = new PhanSo();
            if (a.getTu() / a.getMau() > b.getTu() / b.getMau()) d = a;
            else d = b;
            grKQ.Text = "Kết quả Nhân";
            txtKQTS.Text = c.getTu().ToString();
            txtKQMS.Text = c.getMau().ToString();
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            PhanSo a = new PhanSo(int.Parse(txtTS1.Text), int.Parse(txtMS1.Text));
            PhanSo b = new PhanSo(int.Parse(txtTS2.Text), int.Parse(txtMS2.Text));
            PhanSo c = a / b;
            PhanSo d = new PhanSo();
            if (a.getTu() / a.getMau() > b.getTu() / b.getMau()) d = a;
            else d = b;
            grKQ.Text = "Kết quả Chia";
            txtKQTS.Text = c.getTu().ToString();
            txtKQMS.Text = c.getMau().ToString();
        }
    }
}
