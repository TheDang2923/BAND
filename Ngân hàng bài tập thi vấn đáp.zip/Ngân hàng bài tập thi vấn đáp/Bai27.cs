﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai27 : Form
    {
        public Bai27()
        {
            InitializeComponent();
        }

        private void btnNhap_Click(object sender, EventArgs e)
        {
            // Lấy thông tin từ người dùng
            string hoTen = txtHoTen.Text;
            DateTime ngaySinh = DateTime.Parse(txtNgaySinh.Text);
            bool gioiTinhNam = radNam.Checked;

            // Tính số tuổi
            int tuoi = TinhTuoi(ngaySinh);

            // Xác định nhân xưng
            string nhanXung = XacDinhNhanXung(gioiTinhNam);

            // Hiển thị kết quả
            MessageBox.Show($"Họ tên: {hoTen}, {nhanXung} {tuoi} tuổi, sinh vào ngày thứ ...");
        }
        private int TinhTuoi(DateTime ngaySinh)
        {
            DateTime ngayHienTai = DateTime.Now;
            int tuoi = ngayHienTai.Year - ngaySinh.Year;

            // Kiểm tra nếu chưa đến sinh nhật trong năm thì giảm tuổi đi 1
            if (ngayHienTai.Month < ngaySinh.Month || (ngayHienTai.Month == ngaySinh.Month && ngayHienTai.Day < ngaySinh.Day))
            {
                tuoi--;
            }

            return tuoi;
        }

        private string XacDinhNhanXung(bool gioiTinhNam)
        {
            return gioiTinhNam ? "anh" : "chị";
        }

        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
