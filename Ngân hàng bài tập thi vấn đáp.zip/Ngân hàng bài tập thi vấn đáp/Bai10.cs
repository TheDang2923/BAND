﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai10 : Form
    {
        public Bai10()
        {
            InitializeComponent();
        }

        private void btnin_Click(object sender, EventArgs e)
        {
            string menu = string.Join("\n", lst2.Items.OfType<string>());
            MessageBox.Show("Thực đơn:\n" + menu);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnSP_Click(object sender, EventArgs e)
        {
            if (lst1.SelectedItem != null)
            {
                string selectedValue = lst1.SelectedItem.ToString();
                lst2.Items.Add(selectedValue);
                lst1.Items.Remove(selectedValue);
            }
        }

        private void btnST_Click(object sender, EventArgs e)
        {
            if (lst2.SelectedItem != null)
            {
                string selectedValue = lst2.SelectedItem.ToString();
                lst2.Items.Remove(selectedValue);
                lst1.Items.Add(selectedValue);
            }
        }

        private void btnSSP_Click(object sender, EventArgs e)
        {
            foreach (var item in lst1.Items.OfType<string>().ToList())
            {
                lst2.Items.Add(item);
                lst1.Items.Remove(item);
            }
        }

        private void btnSST_Click(object sender, EventArgs e)
        {
            foreach (var item in lst2.Items.OfType<string>().ToList())
            {
                lst1.Items.Add(item);
                lst2.Items.Remove(item);
            }
        }
    }
}
