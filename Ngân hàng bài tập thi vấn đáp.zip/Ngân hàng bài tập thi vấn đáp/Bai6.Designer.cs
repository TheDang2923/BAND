﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.btnCN = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSum = new System.Windows.Forms.Button();
            this.btnXoaDauCuoi = new System.Windows.Forms.Button();
            this.btnXoaDangChon = new System.Windows.Forms.Button();
            this.btnTang2 = new System.Windows.Forms.Button();
            this.btnBP = new System.Windows.Forms.Button();
            this.btnSC = new System.Windows.Forms.Button();
            this.btnSL = new System.Windows.Forms.Button();
            this.btnKT = new System.Windows.Forms.Button();
            this.lstBoxA = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập số";
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(183, 36);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(329, 36);
            this.txtAdd.TabIndex = 0;
            // 
            // btnCN
            // 
            this.btnCN.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCN.Location = new System.Drawing.Point(542, 36);
            this.btnCN.Name = "btnCN";
            this.btnCN.Size = new System.Drawing.Size(151, 36);
            this.btnCN.TabIndex = 1;
            this.btnCN.Text = "Cập nhật";
            this.btnCN.UseVisualStyleBackColor = false;
            this.btnCN.Click += new System.EventHandler(this.btnCN_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstBoxA);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(28, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(321, 311);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lớp A";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSL);
            this.groupBox2.Controls.Add(this.btnSC);
            this.groupBox2.Controls.Add(this.btnBP);
            this.groupBox2.Controls.Add(this.btnTang2);
            this.groupBox2.Controls.Add(this.btnXoaDangChon);
            this.groupBox2.Controls.Add(this.btnXoaDauCuoi);
            this.groupBox2.Controls.Add(this.btnSum);
            this.groupBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(355, 78);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(358, 311);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Các chức năng";
            // 
            // btnSum
            // 
            this.btnSum.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSum.Location = new System.Drawing.Point(6, 35);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(346, 33);
            this.btnSum.TabIndex = 1;
            this.btnSum.Text = "Tổng của danh sách";
            this.btnSum.UseVisualStyleBackColor = false;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // btnXoaDauCuoi
            // 
            this.btnXoaDauCuoi.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnXoaDauCuoi.Location = new System.Drawing.Point(6, 74);
            this.btnXoaDauCuoi.Name = "btnXoaDauCuoi";
            this.btnXoaDauCuoi.Size = new System.Drawing.Size(346, 33);
            this.btnXoaDauCuoi.TabIndex = 2;
            this.btnXoaDauCuoi.Text = "Xóa phần tử đầu cuối";
            this.btnXoaDauCuoi.UseVisualStyleBackColor = false;
            this.btnXoaDauCuoi.Click += new System.EventHandler(this.btnXoaDauCuoi_Click);
            // 
            // btnXoaDangChon
            // 
            this.btnXoaDangChon.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnXoaDangChon.Location = new System.Drawing.Point(6, 113);
            this.btnXoaDangChon.Name = "btnXoaDangChon";
            this.btnXoaDangChon.Size = new System.Drawing.Size(346, 33);
            this.btnXoaDangChon.TabIndex = 3;
            this.btnXoaDangChon.Text = "Xóa phần tử đang chọn";
            this.btnXoaDangChon.UseVisualStyleBackColor = false;
            this.btnXoaDangChon.Click += new System.EventHandler(this.btnXoaDangChon_Click);
            // 
            // btnTang2
            // 
            this.btnTang2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnTang2.Location = new System.Drawing.Point(6, 152);
            this.btnTang2.Name = "btnTang2";
            this.btnTang2.Size = new System.Drawing.Size(346, 33);
            this.btnTang2.TabIndex = 4;
            this.btnTang2.Text = "Tăng mỗi phần tử lên 2";
            this.btnTang2.UseVisualStyleBackColor = false;
            this.btnTang2.Click += new System.EventHandler(this.btnTang2_Click);
            // 
            // btnBP
            // 
            this.btnBP.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnBP.Location = new System.Drawing.Point(6, 191);
            this.btnBP.Name = "btnBP";
            this.btnBP.Size = new System.Drawing.Size(346, 33);
            this.btnBP.TabIndex = 5;
            this.btnBP.Text = "Thay bằng bình phương";
            this.btnBP.UseVisualStyleBackColor = false;
            this.btnBP.Click += new System.EventHandler(this.btnBP_Click);
            // 
            // btnSC
            // 
            this.btnSC.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSC.Location = new System.Drawing.Point(6, 230);
            this.btnSC.Name = "btnSC";
            this.btnSC.Size = new System.Drawing.Size(346, 33);
            this.btnSC.TabIndex = 6;
            this.btnSC.Text = "Chọn số chẵn";
            this.btnSC.UseVisualStyleBackColor = false;
            this.btnSC.Click += new System.EventHandler(this.btnSC_Click);
            // 
            // btnSL
            // 
            this.btnSL.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSL.Location = new System.Drawing.Point(6, 269);
            this.btnSL.Name = "btnSL";
            this.btnSL.Size = new System.Drawing.Size(346, 33);
            this.btnSL.TabIndex = 0;
            this.btnSL.Text = "Chọn số lẻ";
            this.btnSL.UseVisualStyleBackColor = false;
            this.btnSL.Click += new System.EventHandler(this.btnSL_Click);
            // 
            // btnKT
            // 
            this.btnKT.BackColor = System.Drawing.SystemColors.Control;
            this.btnKT.Location = new System.Drawing.Point(28, 395);
            this.btnKT.Name = "btnKT";
            this.btnKT.Size = new System.Drawing.Size(685, 45);
            this.btnKT.TabIndex = 3;
            this.btnKT.Text = "KẾT THÚC";
            this.btnKT.UseVisualStyleBackColor = false;
            this.btnKT.Click += new System.EventHandler(this.btnKT_Click);
            // 
            // lstBoxA
            // 
            this.lstBoxA.FormattingEnabled = true;
            this.lstBoxA.ItemHeight = 24;
            this.lstBoxA.Location = new System.Drawing.Point(12, 46);
            this.lstBoxA.Name = "lstBoxA";
            this.lstBoxA.Size = new System.Drawing.Size(303, 244);
            this.lstBoxA.TabIndex = 0;
            this.lstBoxA.SelectedIndexChanged += new System.EventHandler(this.lstBoxA_SelectedIndexChanged);
            // 
            // Bai6
            // 
            this.AcceptButton = this.btnCN;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnKT;
            this.ClientSize = new System.Drawing.Size(742, 460);
            this.Controls.Add(this.btnKT);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCN);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài tập ListBox";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Button btnCN;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSL;
        private System.Windows.Forms.Button btnSC;
        private System.Windows.Forms.Button btnBP;
        private System.Windows.Forms.Button btnTang2;
        private System.Windows.Forms.Button btnXoaDangChon;
        private System.Windows.Forms.Button btnXoaDauCuoi;
        private System.Windows.Forms.Button btnSum;
        private System.Windows.Forms.Button btnKT;
        private System.Windows.Forms.ListBox lstBoxA;
    }
}