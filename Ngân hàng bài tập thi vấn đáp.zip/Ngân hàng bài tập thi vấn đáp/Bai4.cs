﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai4 : Form
    {
        public Bai4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;

            if (radioButtonRed.Checked)
                textBox1.ForeColor = Color.Red;
            else if (radioButtonBlue.Checked)
                textBox1.ForeColor = Color.Blue;
            else if (radioButtonBlack.Checked)
                textBox1.ForeColor = Color.Black;

            FontFamily f = new FontFamily("Times New Roman");
            int fontSize = 20;
            FontStyle fontStyle = FontStyle.Regular;

            if (checkBoxBold.Checked)
                fontStyle |= FontStyle.Bold;
            if (checkBoxItalic.Checked)
                fontStyle |= FontStyle.Italic;
            if (checkBoxUnderline.Checked)
                fontStyle |= FontStyle.Underline;

            textBox1.Font = new Font(f, fontSize, fontStyle);
            textBox1.Text = text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
