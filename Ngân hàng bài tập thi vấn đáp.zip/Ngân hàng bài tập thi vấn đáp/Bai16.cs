﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai16 : Form
    {
        public Bai16()
        {
            InitializeComponent();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Lấy thông tin từ các controls trên giao diện
            string hoTen = txtHoTen.Text;
            string lop = txtLop.Text;
            List<string> monHocDaChon = new List<string>();

            if (chkLTC.Checked)
                monHocDaChon.Add(chkLTC.Text);
            if (chkMMT.Checked)
                monHocDaChon.Add(chkMMT.Text);
            if (chkXLA.Checked)
                monHocDaChon.Add(chkXLA.Text);
            if (chkLTW.Checked)
                monHocDaChon.Add(chkLTW.Text);

            // Hiển thị thông tin trong MessageBox
            string thongTin = $"Họ tên: {hoTen}\nLớp: {lop}\nMôn học đã chọn: {string.Join(", ", monHocDaChon)}";
            MessageBox.Show(thongTin, "Thông tin sinh viên", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
