﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai17 : Form
    {
        private int a = 0;
        private int b = 0;
        private float x = 0;
        Random rd = new Random();
        public Bai17()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ProGressTG.Value == 30000)
            {
                timer1.Enabled = true;
                MessageBox.Show($"Hết giờ làm bài.\nĐáp án đúng là: {x}", "Thông báo");
            }
            ProGressTG.PerformStep();
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            float kq = float.Parse(txtNhapNghiem.Text);
            if (Math.Abs(kq - x) < 0.01)
            {
                MessageBox.Show("Bạn đã trả lời đúng");
                Close();
            }
            else
                MessageBox.Show("Bạn đã trả lời sai -> Bạn ngu vl!!!");
        }

        private void Bai17_Load(object sender, EventArgs e)
        {
            a = rd.Next(-10, 10);
            txthsa.Text = a.ToString();
            b = rd.Next(-10, 10);
            txthsb.Text = b.ToString();
            x = -b / (float)a;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
