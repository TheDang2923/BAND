﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai12 : Form
    {
        public Bai12()
        {
            InitializeComponent();
        }
        private bool SoNguyenTo(int num)
        {
            // so nguyen n < 2 khong phai la so nguyen to
            if (num < 2)
            {
                return false;
            }
            // check so nguyen to khi n >= 2
            int x = (int)Math.Sqrt(num);
            int i;
            for (i = 2; i <= x; i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
            return true;
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            int N = int.Parse(txtnhapN.Text);
            string kq = "";

            for (int i = 2; i <= N; i++)
            {
                if (SoNguyenTo(i))
                {
                    kq += i + " ";
                }
            }

            //Hiển thị KQ
            txtKQ.Text = kq;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
