﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class All : Form
    {
        public All()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bai1 bai1 = new Bai1();
            bai1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bai2 bai2 = new Bai2();
            bai2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Bai3 bai3 = new Bai3();
            bai3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Bai4 bai4 = new Bai4();
            bai4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Bai5 bai5 = new Bai5();
            bai5.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Bai6 bai6 = new Bai6();
            bai6.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Bai7 bai7 = new Bai7();
            bai7.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Bai8 bai8 = new Bai8();
            bai8.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Bai9 bai9 = new Bai9();
            bai9.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Bai10 bai10 = new Bai10();
            bai10.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Bai11 bai11 = new Bai11();
            bai11.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Bai12 bai12 = new Bai12();
            bai12.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Bai13 bai13 = new Bai13();
            bai13.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Bai14 bai14 = new Bai14();
            bai14.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Bai15 bai15 = new Bai15();
            bai15.ShowDialog();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Bai16 bai16 = new Bai16();
            bai16.ShowDialog();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Bai17 bai17 = new Bai17();
            bai17.ShowDialog();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Bai18 bai18 = new Bai18();
            bai18.ShowDialog();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Bai19 bai19 = new Bai19();
            bai19.ShowDialog();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Bai20 bai20 = new Bai20();
            bai20.ShowDialog();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Bai21 bai21 = new Bai21();
            bai21.ShowDialog();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Bai22 bai22 = new Bai22();
            bai22.ShowDialog();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Bai23 bai23 = new Bai23();
            bai23.ShowDialog();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            Bai24 bai24 = new Bai24();
            bai24.ShowDialog();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            Bai25 bai25 = new Bai25();
            bai25.ShowDialog();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            Bai26 bai26 = new Bai26();
            bai26.ShowDialog();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Bai27 bai27 = new Bai27();
            bai27.ShowDialog();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            Bai28 bai28 = new Bai28();
            bai28.ShowDialog();
        }
    }
}
