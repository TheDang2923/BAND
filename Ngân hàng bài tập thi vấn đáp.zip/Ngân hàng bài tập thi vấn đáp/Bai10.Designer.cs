﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lst1 = new System.Windows.Forms.ListBox();
            this.lst2 = new System.Windows.Forms.ListBox();
            this.btnSP = new System.Windows.Forms.Button();
            this.btnST = new System.Windows.Forms.Button();
            this.btnSSP = new System.Windows.Forms.Button();
            this.btnSST = new System.Windows.Forms.Button();
            this.btnin = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(815, 80);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(249, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thực đơn trong ngày";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btnExit);
            this.panel2.Controls.Add(this.btnin);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 419);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(815, 80);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "Danh sách món ăn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(503, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Danh sách thực đơn ngày";
            // 
            // lst1
            // 
            this.lst1.FormattingEnabled = true;
            this.lst1.ItemHeight = 28;
            this.lst1.Items.AddRange(new object[] {
            "Bò kho",
            "Phở bò",
            "Phở gà",
            "Bún măng",
            "Bún bò",
            "Bún riêu",
            "Mì xào thập cẩm",
            "Mì xào bò",
            "Mì xào chay"});
            this.lst1.Location = new System.Drawing.Point(27, 129);
            this.lst1.Name = "lst1";
            this.lst1.Size = new System.Drawing.Size(320, 284);
            this.lst1.TabIndex = 3;
            // 
            // lst2
            // 
            this.lst2.FormattingEnabled = true;
            this.lst2.ItemHeight = 28;
            this.lst2.Location = new System.Drawing.Point(466, 129);
            this.lst2.Name = "lst2";
            this.lst2.Size = new System.Drawing.Size(320, 284);
            this.lst2.TabIndex = 3;
            // 
            // btnSP
            // 
            this.btnSP.Location = new System.Drawing.Point(377, 179);
            this.btnSP.Name = "btnSP";
            this.btnSP.Size = new System.Drawing.Size(51, 40);
            this.btnSP.TabIndex = 4;
            this.btnSP.Text = ">";
            this.btnSP.UseVisualStyleBackColor = true;
            this.btnSP.Click += new System.EventHandler(this.btnSP_Click);
            // 
            // btnST
            // 
            this.btnST.Location = new System.Drawing.Point(377, 225);
            this.btnST.Name = "btnST";
            this.btnST.Size = new System.Drawing.Size(51, 40);
            this.btnST.TabIndex = 4;
            this.btnST.Text = "<";
            this.btnST.UseVisualStyleBackColor = true;
            this.btnST.Click += new System.EventHandler(this.btnST_Click);
            // 
            // btnSSP
            // 
            this.btnSSP.Location = new System.Drawing.Point(377, 271);
            this.btnSSP.Name = "btnSSP";
            this.btnSSP.Size = new System.Drawing.Size(51, 40);
            this.btnSSP.TabIndex = 4;
            this.btnSSP.Text = ">>";
            this.btnSSP.UseVisualStyleBackColor = true;
            this.btnSSP.Click += new System.EventHandler(this.btnSSP_Click);
            // 
            // btnSST
            // 
            this.btnSST.Location = new System.Drawing.Point(377, 317);
            this.btnSST.Name = "btnSST";
            this.btnSST.Size = new System.Drawing.Size(51, 40);
            this.btnSST.TabIndex = 4;
            this.btnSST.Text = "<<";
            this.btnSST.UseVisualStyleBackColor = true;
            this.btnSST.Click += new System.EventHandler(this.btnSST_Click);
            // 
            // btnin
            // 
            this.btnin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnin.Location = new System.Drawing.Point(187, 17);
            this.btnin.Name = "btnin";
            this.btnin.Size = new System.Drawing.Size(175, 46);
            this.btnin.TabIndex = 0;
            this.btnin.Text = "In thực đơn";
            this.btnin.UseVisualStyleBackColor = false;
            this.btnin.Click += new System.EventHandler(this.btnin_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Location = new System.Drawing.Point(450, 17);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(175, 46);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Thoát";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Bai10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 499);
            this.Controls.Add(this.btnSST);
            this.Controls.Add(this.btnSSP);
            this.Controls.Add(this.btnST);
            this.Controls.Add(this.btnSP);
            this.Controls.Add(this.lst2);
            this.Controls.Add(this.lst1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai10";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách món ăn";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lst1;
        private System.Windows.Forms.ListBox lst2;
        private System.Windows.Forms.Button btnSP;
        private System.Windows.Forms.Button btnST;
        private System.Windows.Forms.Button btnSSP;
        private System.Windows.Forms.Button btnSST;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnin;
    }
}