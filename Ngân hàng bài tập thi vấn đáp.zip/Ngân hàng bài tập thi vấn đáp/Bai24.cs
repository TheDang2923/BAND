﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai24 : Form
    {
        public Bai24()
        {
            InitializeComponent();
        }

        private void btnChonMau_Click(object sender, EventArgs e)
        {
            ColorDialog clDLog = new ColorDialog();
            DialogResult rs = clDLog.ShowDialog();
            if (rs == DialogResult.OK)
            {
                if (radMauChu.Checked == true)
                {
                    lblHienThi.ForeColor = clDLog.Color;
                }
                if (radMauNen.Checked == true)
                {
                    lblHienThi.BackColor = clDLog.Color;
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
