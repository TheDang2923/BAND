﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai11 : Form
    {
        public Bai11()
        {
            InitializeComponent();
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNhapa.Text, out int a) && int.TryParse(txtNhapb.Text, out int b))
            {
                // Tính UCLN và BCNN
                int ucln = TinhUCLN(a, b);
                int bcnn = TinhBCNN(a, b);

                // Hiển thị kết quả
                txtUSCLN.Text = $"{ucln}";
                txtBCNN.Text = $"{bcnn}";
            }
        }

        private static int TinhUCLN(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        private static int TinhBCNN(int a, int b)
        {
            return (a * b) / TinhUCLN(a, b);
        }

        private void btnTiepTuc_Click(object sender, EventArgs e)
        {
            txtNhapa.Clear();
            txtNhapb.Clear();
            txtBCNN.Clear();
            txtUSCLN.Clear();
            txtNhapa.Focus();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
