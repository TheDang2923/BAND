﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string TenHang = string.Empty;
            int intSoLuong = int.Parse(txtSoLuong.Text);
            decimal decDonGia = decimal.Parse(txtDonGia.Text);
            decimal decThanhTien;

            if (txtSoLuong.Text == "")
            {
                MessageBox.Show("Chưa nhập số lượng hàng");
                txtSoLuong.Focus();
            }
            else if (txtDonGia.Text == "")
            {
                MessageBox.Show("Chưa nhập đơn giá hàng");
                txtDonGia.Focus();
            }
            else
            {
                int SoLuong = Convert.ToInt32(txtSoLuong.Text);
                decimal DonGia = Convert.ToDecimal(txtDonGia.Text);
            }

            if (intSoLuong < 0)
            {
                MessageBox.Show("Số lượng hàng > 0");
                txtSoLuong.SelectAll();
                txtSoLuong.Focus();
            }

            else if (decDonGia < 0)
            {
                MessageBox.Show("Đơn giá > 0");
                txtDonGia.SelectAll();
                txtDonGia.Focus();
            }

            else
            {
                decThanhTien = intSoLuong * decDonGia;
                txtThanhTien.Text = decThanhTien.ToString();
            }
        }

        private void btnTiep_Click(object sender, EventArgs e)
        {
            txtDonGia.Clear();
            txtTenHang.Clear();
            txtSoLuong.Clear();
        }

        private void btnKetThuc_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
