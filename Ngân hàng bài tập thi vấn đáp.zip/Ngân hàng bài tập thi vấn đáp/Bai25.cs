﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai25 : Form
    {
        public Bai25()
        {
            InitializeComponent();
        }

        private void btnMoTapTin_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string tentaptin = openFileDialog1.FileName;
                StreamReader rd = new StreamReader(tentaptin);
                txtNoiDung.Text = rd.ReadToEnd();
                rd.Close();
            }
        }

        private void btnLuuTapTin_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string noidung = txtNoiDung.Text;
                string tentaptin = saveFileDialog1.FileName;
                StreamWriter wt = new StreamWriter(tentaptin);
                wt.Write(noidung);
                wt.Close();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
