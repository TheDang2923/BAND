﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai28
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtHoDem = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.radNam = new System.Windows.Forms.RadioButton();
            this.radNu = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.chkTiengAnh = new System.Windows.Forms.CheckBox();
            this.chkTiengTrung = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnNhapThongTin = new System.Windows.Forms.Button();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ đệm:";
            // 
            // txtHoDem
            // 
            this.txtHoDem.Location = new System.Drawing.Point(159, 23);
            this.txtHoDem.Name = "txtHoDem";
            this.txtHoDem.Size = new System.Drawing.Size(290, 36);
            this.txtHoDem.TabIndex = 0;
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(159, 65);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(290, 36);
            this.txtTen.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Giới tính:";
            // 
            // radNam
            // 
            this.radNam.AutoSize = true;
            this.radNam.Location = new System.Drawing.Point(159, 116);
            this.radNam.Name = "radNam";
            this.radNam.Size = new System.Drawing.Size(77, 32);
            this.radNam.TabIndex = 2;
            this.radNam.TabStop = true;
            this.radNam.Text = "Nam";
            this.radNam.UseVisualStyleBackColor = true;
            // 
            // radNu
            // 
            this.radNu.AutoSize = true;
            this.radNu.Location = new System.Drawing.Point(299, 116);
            this.radNu.Name = "radNu";
            this.radNu.Size = new System.Drawing.Size(62, 32);
            this.radNu.TabIndex = 3;
            this.radNu.TabStop = true;
            this.radNu.Text = "Nữ";
            this.radNu.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 28);
            this.label4.TabIndex = 0;
            this.label4.Text = "Ngoại ngữ:";
            // 
            // chkTiengAnh
            // 
            this.chkTiengAnh.AutoSize = true;
            this.chkTiengAnh.Location = new System.Drawing.Point(159, 160);
            this.chkTiengAnh.Name = "chkTiengAnh";
            this.chkTiengAnh.Size = new System.Drawing.Size(126, 32);
            this.chkTiengAnh.TabIndex = 4;
            this.chkTiengAnh.Text = "Tiếng Anh";
            this.chkTiengAnh.UseVisualStyleBackColor = true;
            // 
            // chkTiengTrung
            // 
            this.chkTiengTrung.AutoSize = true;
            this.chkTiengTrung.Location = new System.Drawing.Point(299, 160);
            this.chkTiengTrung.Name = "chkTiengTrung";
            this.chkTiengTrung.Size = new System.Drawing.Size(142, 32);
            this.chkTiengTrung.TabIndex = 5;
            this.chkTiengTrung.Text = "Tiếng Trung";
            this.chkTiengTrung.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Quê quán:";
            // 
            // btnNhapThongTin
            // 
            this.btnNhapThongTin.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnNhapThongTin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapThongTin.Location = new System.Drawing.Point(49, 370);
            this.btnNhapThongTin.Name = "btnNhapThongTin";
            this.btnNhapThongTin.Size = new System.Drawing.Size(174, 50);
            this.btnNhapThongTin.TabIndex = 7;
            this.btnNhapThongTin.Text = "Xem thông tin";
            this.btnNhapThongTin.UseVisualStyleBackColor = true;
            this.btnNhapThongTin.Click += new System.EventHandler(this.btnNhapThongTin_Click);
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnNhapLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapLai.Location = new System.Drawing.Point(257, 370);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(174, 50);
            this.btnNhapLai.TabIndex = 8;
            this.btnNhapLai.Text = "Nhập lại";
            this.btnNhapLai.UseVisualStyleBackColor = true;
            this.btnNhapLai.Click += new System.EventHandler(this.btnNhapLai_Click);
            // 
            // listBox1
            // 
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 28;
            this.listBox1.Items.AddRange(new object[] {
            "Hà Nội",
            "TP. Hồ Chí Minh",
            "Hải Phòng",
            "Đà Nẵng"});
            this.listBox1.Location = new System.Drawing.Point(159, 210);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(290, 142);
            this.listBox1.TabIndex = 6;
            // 
            // Bai28
            // 
            this.AcceptButton = this.btnNhapThongTin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnNhapLai;
            this.ClientSize = new System.Drawing.Size(479, 437);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btnNhapLai);
            this.Controls.Add(this.btnNhapThongTin);
            this.Controls.Add(this.chkTiengTrung);
            this.Controls.Add(this.chkTiengAnh);
            this.Controls.Add(this.radNu);
            this.Controls.Add(this.radNam);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.txtHoDem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai28";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ví dụ Control - WPF";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtHoDem;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radNam;
        private System.Windows.Forms.RadioButton radNu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkTiengAnh;
        private System.Windows.Forms.CheckBox chkTiengTrung;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnNhapThongTin;
        private System.Windows.Forms.Button btnNhapLai;
        private System.Windows.Forms.ListBox listBox1;
    }
}