﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai9 : Form
    {
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Point ballPosition = new Point(100, 100);
        private int ballSpeedX = 5;
        private int ballSpeedY = 5;
        public Bai9()
        {
            InitializeComponent();
            InitializeBall();
        }
        private void InitializeBall()
        {
            timer.Interval = 20;
            timer.Tick += new EventHandler(UpdateBallPosition);
            timer.Start();
        }

        private void UpdateBallPosition(object sender, EventArgs e)
        {
            ballPosition.X += ballSpeedX;
            ballPosition.Y += ballSpeedY;

            if (ballPosition.X < 0 || ballPosition.X + 50 > this.ClientSize.Width)
            {
                ballSpeedX = -ballSpeedX;
            }
            if (ballPosition.Y < 0 || ballPosition.Y + 50 > this.ClientSize.Height)
            {
                ballSpeedY = -ballSpeedY;
            }

            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.FillEllipse(Brushes.Red, ballPosition.X, ballPosition.Y, 50, 50);
        }
    }
}
