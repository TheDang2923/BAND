﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai18 : Form
    {
        public Bai18()
        {
            InitializeComponent();
            listView.View = View.Details;
            listView.Columns.Add("Tên Lớp", 100);
            listView.Columns.Add("Số lượng sinh viên", 190);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string tenLop = txtTenlop.Text;
            string soLuongSV = txtSoLuongsv.Text;

            if (!string.IsNullOrEmpty(tenLop) && !string.IsNullOrEmpty(soLuongSV))
            {
                ListViewItem item = new ListViewItem(tenLop);
                item.SubItems.Add(soLuongSV);
                listView.Items.Add(item);
                txtTenlop.Clear();
                txtSoLuongsv.Clear();
            }
            else
            {
                MessageBox.Show("Hãy nhập tên lớp và số lượng sinh viên.");
            }
        }
    }
}
