﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai26
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.grKQ = new System.Windows.Forms.GroupBox();
            this.btnTiepTuc = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTS1 = new System.Windows.Forms.TextBox();
            this.txtMS1 = new System.Windows.Forms.TextBox();
            this.txtTS2 = new System.Windows.Forms.TextBox();
            this.txtMS2 = new System.Windows.Forms.TextBox();
            this.txtKQTS = new System.Windows.Forms.TextBox();
            this.txtKQMS = new System.Windows.Forms.TextBox();
            this.btnCong = new System.Windows.Forms.Button();
            this.btnTru = new System.Windows.Forms.Button();
            this.btnNhan = new System.Windows.Forms.Button();
            this.btnChia = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grKQ.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(125, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phép Tính Phân Số";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMS1);
            this.groupBox1.Controls.Add(this.txtTS1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(87, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 166);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Phân số 1:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMS2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtTS2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(294, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(171, 166);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Phân số 2:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnChia);
            this.groupBox3.Controls.Add(this.btnNhan);
            this.groupBox3.Controls.Add(this.btnTru);
            this.groupBox3.Controls.Add(this.btnCong);
            this.groupBox3.Location = new System.Drawing.Point(87, 252);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(171, 166);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Phép tính:";
            // 
            // grKQ
            // 
            this.grKQ.Controls.Add(this.txtKQMS);
            this.grKQ.Controls.Add(this.label7);
            this.grKQ.Controls.Add(this.label6);
            this.grKQ.Controls.Add(this.txtKQTS);
            this.grKQ.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.grKQ.Location = new System.Drawing.Point(294, 252);
            this.grKQ.Name = "grKQ";
            this.grKQ.Size = new System.Drawing.Size(171, 166);
            this.grKQ.TabIndex = 5;
            this.grKQ.TabStop = false;
            this.grKQ.Text = "Kết quả Cộng:";
            // 
            // btnTiepTuc
            // 
            this.btnTiepTuc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTiepTuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTiepTuc.Location = new System.Drawing.Point(105, 434);
            this.btnTiepTuc.Name = "btnTiepTuc";
            this.btnTiepTuc.Size = new System.Drawing.Size(127, 44);
            this.btnTiepTuc.TabIndex = 3;
            this.btnTiepTuc.Text = "Tiếp tục";
            this.btnTiepTuc.UseVisualStyleBackColor = false;
            this.btnTiepTuc.Click += new System.EventHandler(this.btnTiepTuc_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Location = new System.Drawing.Point(314, 434);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(127, 44);
            this.btnThoat.TabIndex = 4;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tử số:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mẫu số:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 28);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tử số:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mẫu số:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 28);
            this.label6.TabIndex = 0;
            this.label6.Text = "Tử số:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 28);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mẫu số:";
            // 
            // txtTS1
            // 
            this.txtTS1.Location = new System.Drawing.Point(99, 45);
            this.txtTS1.Name = "txtTS1";
            this.txtTS1.Size = new System.Drawing.Size(66, 36);
            this.txtTS1.TabIndex = 0;
            this.txtTS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMS1
            // 
            this.txtMS1.Location = new System.Drawing.Point(99, 89);
            this.txtMS1.Name = "txtMS1";
            this.txtMS1.Size = new System.Drawing.Size(66, 36);
            this.txtMS1.TabIndex = 1;
            this.txtMS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTS2
            // 
            this.txtTS2.Location = new System.Drawing.Point(99, 45);
            this.txtTS2.Name = "txtTS2";
            this.txtTS2.Size = new System.Drawing.Size(66, 36);
            this.txtTS2.TabIndex = 0;
            this.txtTS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMS2
            // 
            this.txtMS2.Location = new System.Drawing.Point(99, 89);
            this.txtMS2.Name = "txtMS2";
            this.txtMS2.Size = new System.Drawing.Size(66, 36);
            this.txtMS2.TabIndex = 1;
            this.txtMS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtKQTS
            // 
            this.txtKQTS.ForeColor = System.Drawing.Color.Red;
            this.txtKQTS.Location = new System.Drawing.Point(99, 46);
            this.txtKQTS.Name = "txtKQTS";
            this.txtKQTS.ReadOnly = true;
            this.txtKQTS.Size = new System.Drawing.Size(66, 36);
            this.txtKQTS.TabIndex = 1;
            this.txtKQTS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtKQMS
            // 
            this.txtKQMS.ForeColor = System.Drawing.Color.Red;
            this.txtKQMS.Location = new System.Drawing.Point(99, 90);
            this.txtKQMS.Name = "txtKQMS";
            this.txtKQMS.ReadOnly = true;
            this.txtKQMS.Size = new System.Drawing.Size(66, 36);
            this.txtKQMS.TabIndex = 1;
            this.txtKQMS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCong
            // 
            this.btnCong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCong.Location = new System.Drawing.Point(7, 39);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(76, 49);
            this.btnCong.TabIndex = 0;
            this.btnCong.Text = "Cộng";
            this.btnCong.UseVisualStyleBackColor = true;
            this.btnCong.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTru
            // 
            this.btnTru.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTru.Location = new System.Drawing.Point(89, 39);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(76, 49);
            this.btnTru.TabIndex = 1;
            this.btnTru.Text = "Trừ";
            this.btnTru.UseVisualStyleBackColor = true;
            this.btnTru.Click += new System.EventHandler(this.btnTru_Click);
            // 
            // btnNhan
            // 
            this.btnNhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhan.Location = new System.Drawing.Point(7, 98);
            this.btnNhan.Name = "btnNhan";
            this.btnNhan.Size = new System.Drawing.Size(76, 49);
            this.btnNhan.TabIndex = 2;
            this.btnNhan.Text = "Nhân";
            this.btnNhan.UseVisualStyleBackColor = true;
            this.btnNhan.Click += new System.EventHandler(this.btnNhan_Click);
            // 
            // btnChia
            // 
            this.btnChia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChia.Location = new System.Drawing.Point(89, 98);
            this.btnChia.Name = "btnChia";
            this.btnChia.Size = new System.Drawing.Size(76, 49);
            this.btnChia.TabIndex = 3;
            this.btnChia.Text = "Chia";
            this.btnChia.UseVisualStyleBackColor = true;
            this.btnChia.Click += new System.EventHandler(this.btnChia_Click);
            // 
            // Bai26
            // 
            this.AcceptButton = this.btnTiepTuc;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(559, 502);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTiepTuc);
            this.Controls.Add(this.grKQ);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai26";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xử lý phân số";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.grKQ.ResumeLayout(false);
            this.grKQ.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox grKQ;
        private System.Windows.Forms.Button btnTiepTuc;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMS1;
        private System.Windows.Forms.TextBox txtTS1;
        private System.Windows.Forms.TextBox txtMS2;
        private System.Windows.Forms.TextBox txtTS2;
        private System.Windows.Forms.TextBox txtKQMS;
        private System.Windows.Forms.TextBox txtKQTS;
        private System.Windows.Forms.Button btnChia;
        private System.Windows.Forms.Button btnNhan;
        private System.Windows.Forms.Button btnTru;
        private System.Windows.Forms.Button btnCong;
    }
}