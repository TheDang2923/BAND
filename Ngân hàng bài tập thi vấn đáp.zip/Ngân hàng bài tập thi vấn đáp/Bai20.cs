﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai20 : Form
    {
        public Bai20()
        {
            InitializeComponent();
        }

        private void btnThemnodegoc_Click(object sender, EventArgs e)
        {
            TreeNode newNode = new TreeNode(txtTieude.Text);
            treeView1.Nodes.Add(newNode);
        }

        private void btnThemnodedangchon_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                TreeNode newNode = new TreeNode(txtTieude.Text);
                treeView1.SelectedNode.Nodes.Add(newNode);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một node trước khi thêm node con.");
            }
        }

        private void btnXoatatcanode_Click(object sender, EventArgs e)
        {
            treeView1.Nodes.Clear();
        }

        private void btnXoanodedangchon_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                treeView1.SelectedNode.Remove();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một node để xóa.");
            }
        }

        private void btnCong_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtTieude.Text))
            {
                TreeNode newNode = new TreeNode(txtTieude.Text);
                if (treeView1.SelectedNode != null)
                {
                    treeView1.SelectedNode.Nodes.Add(newNode);
                }
                else
                {
                    treeView1.Nodes.Add(newNode);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập tiêu đề cho node mới.");
            }
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                treeView1.SelectedNode.Remove();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một node để xóa.");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Có chắc là bạn muốn đóng ứng dụng?", "warning",
                MessageBoxButtons.YesNo);
            if (dl == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
