﻿namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    partial class Bai22
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.myTabControl = new System.Windows.Forms.TabControl();
            this.tagQuanLyNhanVien = new System.Windows.Forms.TabPage();
            this.tagQuanLyGiaoVien = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtLuongCBNV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtChucVuNV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtHeSoLuongNV = new System.Windows.Forms.TextBox();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.btnCapNhatNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.listNhanVien = new System.Windows.Forms.ListView();
            this.listGiaoVien = new System.Windows.Forms.ListView();
            this.btnXoaGV = new System.Windows.Forms.Button();
            this.btnCapNhatGV = new System.Windows.Forms.Button();
            this.btnThemGV = new System.Windows.Forms.Button();
            this.txtTienDayMotTiet = new System.Windows.Forms.TextBox();
            this.txtSoTietDay = new System.Windows.Forms.TextBox();
            this.txtHocVi = new System.Windows.Forms.TextBox();
            this.txtTenGV = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.colHoTen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colChucVu = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeSoLuong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colLuongCoBan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHoTenGV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHocVi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTienDayMotTiet = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSoTietDay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.myTabControl.SuspendLayout();
            this.tagQuanLyNhanVien.SuspendLayout();
            this.tagQuanLyGiaoVien.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(275, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(249, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản lý nhân sự";
            // 
            // myTabControl
            // 
            this.myTabControl.Controls.Add(this.tagQuanLyNhanVien);
            this.myTabControl.Controls.Add(this.tagQuanLyGiaoVien);
            this.myTabControl.Location = new System.Drawing.Point(12, 53);
            this.myTabControl.Name = "myTabControl";
            this.myTabControl.SelectedIndex = 0;
            this.myTabControl.Size = new System.Drawing.Size(782, 427);
            this.myTabControl.TabIndex = 0;
            // 
            // tagQuanLyNhanVien
            // 
            this.tagQuanLyNhanVien.Controls.Add(this.listNhanVien);
            this.tagQuanLyNhanVien.Controls.Add(this.btnXoaNV);
            this.tagQuanLyNhanVien.Controls.Add(this.btnCapNhatNV);
            this.tagQuanLyNhanVien.Controls.Add(this.btnThemNV);
            this.tagQuanLyNhanVien.Controls.Add(this.txtLuongCBNV);
            this.tagQuanLyNhanVien.Controls.Add(this.txtHeSoLuongNV);
            this.tagQuanLyNhanVien.Controls.Add(this.txtChucVuNV);
            this.tagQuanLyNhanVien.Controls.Add(this.txtTenNV);
            this.tagQuanLyNhanVien.Controls.Add(this.label5);
            this.tagQuanLyNhanVien.Controls.Add(this.label3);
            this.tagQuanLyNhanVien.Controls.Add(this.label4);
            this.tagQuanLyNhanVien.Controls.Add(this.label2);
            this.tagQuanLyNhanVien.Location = new System.Drawing.Point(4, 37);
            this.tagQuanLyNhanVien.Name = "tagQuanLyNhanVien";
            this.tagQuanLyNhanVien.Padding = new System.Windows.Forms.Padding(3);
            this.tagQuanLyNhanVien.Size = new System.Drawing.Size(774, 386);
            this.tagQuanLyNhanVien.TabIndex = 0;
            this.tagQuanLyNhanVien.Text = "Quản lý nhân viên";
            this.tagQuanLyNhanVien.UseVisualStyleBackColor = true;
            // 
            // tagQuanLyGiaoVien
            // 
            this.tagQuanLyGiaoVien.Controls.Add(this.listGiaoVien);
            this.tagQuanLyGiaoVien.Controls.Add(this.btnXoaGV);
            this.tagQuanLyGiaoVien.Controls.Add(this.btnCapNhatGV);
            this.tagQuanLyGiaoVien.Controls.Add(this.btnThemGV);
            this.tagQuanLyGiaoVien.Controls.Add(this.txtTienDayMotTiet);
            this.tagQuanLyGiaoVien.Controls.Add(this.txtSoTietDay);
            this.tagQuanLyGiaoVien.Controls.Add(this.txtHocVi);
            this.tagQuanLyGiaoVien.Controls.Add(this.txtTenGV);
            this.tagQuanLyGiaoVien.Controls.Add(this.label6);
            this.tagQuanLyGiaoVien.Controls.Add(this.label7);
            this.tagQuanLyGiaoVien.Controls.Add(this.label8);
            this.tagQuanLyGiaoVien.Controls.Add(this.label9);
            this.tagQuanLyGiaoVien.Location = new System.Drawing.Point(4, 37);
            this.tagQuanLyGiaoVien.Name = "tagQuanLyGiaoVien";
            this.tagQuanLyGiaoVien.Padding = new System.Windows.Forms.Padding(3);
            this.tagQuanLyGiaoVien.Size = new System.Drawing.Size(774, 386);
            this.tagQuanLyGiaoVien.TabIndex = 1;
            this.tagQuanLyGiaoVien.Text = "Quản lý giáo viên";
            this.tagQuanLyGiaoVien.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "Họ tên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Lương cơ bản:";
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(92, 25);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(281, 36);
            this.txtTenNV.TabIndex = 0;
            this.txtTenNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtLuongCBNV
            // 
            this.txtLuongCBNV.Location = new System.Drawing.Point(158, 67);
            this.txtLuongCBNV.Name = "txtLuongCBNV";
            this.txtLuongCBNV.Size = new System.Drawing.Size(215, 36);
            this.txtLuongCBNV.TabIndex = 2;
            this.txtLuongCBNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(392, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 28);
            this.label4.TabIndex = 0;
            this.label4.Text = "Chức vụ:";
            // 
            // txtChucVuNV
            // 
            this.txtChucVuNV.Location = new System.Drawing.Point(491, 25);
            this.txtChucVuNV.Name = "txtChucVuNV";
            this.txtChucVuNV.Size = new System.Drawing.Size(267, 36);
            this.txtChucVuNV.TabIndex = 1;
            this.txtChucVuNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(392, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Hệ số lương:";
            // 
            // txtHeSoLuongNV
            // 
            this.txtHeSoLuongNV.Location = new System.Drawing.Point(527, 67);
            this.txtHeSoLuongNV.Name = "txtHeSoLuongNV";
            this.txtHeSoLuongNV.Size = new System.Drawing.Size(231, 36);
            this.txtHeSoLuongNV.TabIndex = 3;
            this.txtHeSoLuongNV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnThemNV
            // 
            this.btnThemNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemNV.Location = new System.Drawing.Point(11, 133);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(231, 54);
            this.btnThemNV.TabIndex = 4;
            this.btnThemNV.Text = "Thêm nhân viên";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // btnCapNhatNV
            // 
            this.btnCapNhatNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapNhatNV.Location = new System.Drawing.Point(273, 133);
            this.btnCapNhatNV.Name = "btnCapNhatNV";
            this.btnCapNhatNV.Size = new System.Drawing.Size(231, 54);
            this.btnCapNhatNV.TabIndex = 5;
            this.btnCapNhatNV.Text = "Cập nhật";
            this.btnCapNhatNV.UseVisualStyleBackColor = true;
            this.btnCapNhatNV.Click += new System.EventHandler(this.btnCapNhatNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaNV.Location = new System.Drawing.Point(527, 133);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(231, 54);
            this.btnXoaNV.TabIndex = 6;
            this.btnXoaNV.Text = "Xóa nhân viên";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // listNhanVien
            // 
            this.listNhanVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colHoTen,
            this.colChucVu,
            this.colHeSoLuong,
            this.colLuongCoBan});
            this.listNhanVien.FullRowSelect = true;
            this.listNhanVien.HideSelection = false;
            this.listNhanVien.Location = new System.Drawing.Point(11, 193);
            this.listNhanVien.MultiSelect = false;
            this.listNhanVien.Name = "listNhanVien";
            this.listNhanVien.Size = new System.Drawing.Size(747, 187);
            this.listNhanVien.TabIndex = 3;
            this.listNhanVien.UseCompatibleStateImageBehavior = false;
            this.listNhanVien.View = System.Windows.Forms.View.Details;
            this.listNhanVien.SelectedIndexChanged += new System.EventHandler(this.listNhanVien_SelectedIndexChanged);
            // 
            // listGiaoVien
            // 
            this.listGiaoVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colHoTenGV,
            this.colHocVi,
            this.colTienDayMotTiet,
            this.colSoTietDay});
            this.listGiaoVien.FullRowSelect = true;
            this.listGiaoVien.HideSelection = false;
            this.listGiaoVien.Location = new System.Drawing.Point(11, 193);
            this.listGiaoVien.MultiSelect = false;
            this.listGiaoVien.Name = "listGiaoVien";
            this.listGiaoVien.Size = new System.Drawing.Size(747, 187);
            this.listGiaoVien.TabIndex = 15;
            this.listGiaoVien.UseCompatibleStateImageBehavior = false;
            this.listGiaoVien.View = System.Windows.Forms.View.Details;
            this.listGiaoVien.SelectedIndexChanged += new System.EventHandler(this.listGiaoVien_SelectedIndexChanged);
            // 
            // btnXoaGV
            // 
            this.btnXoaGV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaGV.Location = new System.Drawing.Point(527, 133);
            this.btnXoaGV.Name = "btnXoaGV";
            this.btnXoaGV.Size = new System.Drawing.Size(231, 54);
            this.btnXoaGV.TabIndex = 6;
            this.btnXoaGV.Text = "Xóa giáo viên";
            this.btnXoaGV.UseVisualStyleBackColor = true;
            this.btnXoaGV.Click += new System.EventHandler(this.btnXoaGV_Click);
            // 
            // btnCapNhatGV
            // 
            this.btnCapNhatGV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapNhatGV.Location = new System.Drawing.Point(273, 133);
            this.btnCapNhatGV.Name = "btnCapNhatGV";
            this.btnCapNhatGV.Size = new System.Drawing.Size(231, 54);
            this.btnCapNhatGV.TabIndex = 5;
            this.btnCapNhatGV.Text = "Cập nhật";
            this.btnCapNhatGV.UseVisualStyleBackColor = true;
            this.btnCapNhatGV.Click += new System.EventHandler(this.btnCapNhatGV_Click);
            // 
            // btnThemGV
            // 
            this.btnThemGV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemGV.Location = new System.Drawing.Point(11, 133);
            this.btnThemGV.Name = "btnThemGV";
            this.btnThemGV.Size = new System.Drawing.Size(231, 54);
            this.btnThemGV.TabIndex = 4;
            this.btnThemGV.Text = "Thêm giáo viên";
            this.btnThemGV.UseVisualStyleBackColor = true;
            this.btnThemGV.Click += new System.EventHandler(this.btnThemGV_Click);
            // 
            // txtTienDayMotTiet
            // 
            this.txtTienDayMotTiet.Location = new System.Drawing.Point(187, 67);
            this.txtTienDayMotTiet.Name = "txtTienDayMotTiet";
            this.txtTienDayMotTiet.Size = new System.Drawing.Size(186, 36);
            this.txtTienDayMotTiet.TabIndex = 2;
            this.txtTienDayMotTiet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSoTietDay
            // 
            this.txtSoTietDay.Location = new System.Drawing.Point(514, 67);
            this.txtSoTietDay.Name = "txtSoTietDay";
            this.txtSoTietDay.Size = new System.Drawing.Size(244, 36);
            this.txtSoTietDay.TabIndex = 3;
            this.txtSoTietDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtHocVi
            // 
            this.txtHocVi.Location = new System.Drawing.Point(472, 25);
            this.txtHocVi.Name = "txtHocVi";
            this.txtHocVi.Size = new System.Drawing.Size(286, 36);
            this.txtHocVi.TabIndex = 1;
            this.txtHocVi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTenGV
            // 
            this.txtTenGV.Location = new System.Drawing.Point(92, 25);
            this.txtTenGV.Name = "txtTenGV";
            this.txtTenGV.Size = new System.Drawing.Size(281, 36);
            this.txtTenGV.TabIndex = 0;
            this.txtTenGV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(392, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 28);
            this.label6.TabIndex = 4;
            this.label6.Text = "Số tiết dạy:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(175, 28);
            this.label7.TabIndex = 5;
            this.label7.Text = "Tiền dạy một tiết:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(392, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 28);
            this.label8.TabIndex = 6;
            this.label8.Text = "Học vị:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 28);
            this.label9.TabIndex = 7;
            this.label9.Text = "Họ tên:";
            // 
            // btnThoat
            // 
            this.btnThoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Location = new System.Drawing.Point(661, 482);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(128, 37);
            this.btnThoat.TabIndex = 1;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // colHoTen
            // 
            this.colHoTen.Text = "Họ tên";
            this.colHoTen.Width = 190;
            // 
            // colChucVu
            // 
            this.colChucVu.Text = "Chức vụ";
            this.colChucVu.Width = 110;
            // 
            // colHeSoLuong
            // 
            this.colHeSoLuong.Text = "Hệ số lương";
            this.colHeSoLuong.Width = 190;
            // 
            // colLuongCoBan
            // 
            this.colLuongCoBan.Text = "Lương cơ bản";
            this.colLuongCoBan.Width = 190;
            // 
            // colHoTenGV
            // 
            this.colHoTenGV.Text = "Họ tên";
            this.colHoTenGV.Width = 190;
            // 
            // colHocVi
            // 
            this.colHocVi.Text = "Học vị";
            this.colHocVi.Width = 110;
            // 
            // colTienDayMotTiet
            // 
            this.colTienDayMotTiet.Text = "Tiền dạy một tiết";
            this.colTienDayMotTiet.Width = 190;
            // 
            // colSoTietDay
            // 
            this.colSoTietDay.Text = "Số tiết dạy";
            this.colSoTietDay.Width = 190;
            // 
            // Bai22
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnThoat;
            this.ClientSize = new System.Drawing.Size(799, 531);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.myTabControl);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Bai22";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TabControl";
            this.myTabControl.ResumeLayout(false);
            this.tagQuanLyNhanVien.ResumeLayout(false);
            this.tagQuanLyNhanVien.PerformLayout();
            this.tagQuanLyGiaoVien.ResumeLayout(false);
            this.tagQuanLyGiaoVien.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl myTabControl;
        private System.Windows.Forms.TabPage tagQuanLyNhanVien;
        private System.Windows.Forms.TabPage tagQuanLyGiaoVien;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLuongCBNV;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtHeSoLuongNV;
        private System.Windows.Forms.TextBox txtChucVuNV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnCapNhatNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.ListView listNhanVien;
        private System.Windows.Forms.ListView listGiaoVien;
        private System.Windows.Forms.Button btnXoaGV;
        private System.Windows.Forms.Button btnCapNhatGV;
        private System.Windows.Forms.Button btnThemGV;
        private System.Windows.Forms.TextBox txtTienDayMotTiet;
        private System.Windows.Forms.TextBox txtSoTietDay;
        private System.Windows.Forms.TextBox txtHocVi;
        private System.Windows.Forms.TextBox txtTenGV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.ColumnHeader colHoTen;
        private System.Windows.Forms.ColumnHeader colChucVu;
        private System.Windows.Forms.ColumnHeader colHeSoLuong;
        private System.Windows.Forms.ColumnHeader colLuongCoBan;
        private System.Windows.Forms.ColumnHeader colHoTenGV;
        private System.Windows.Forms.ColumnHeader colHocVi;
        private System.Windows.Forms.ColumnHeader colTienDayMotTiet;
        private System.Windows.Forms.ColumnHeader colSoTietDay;
    }
}