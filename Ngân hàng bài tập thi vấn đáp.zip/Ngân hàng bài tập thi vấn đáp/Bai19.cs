﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ngân_hàng_bài_tập_thi_vấn_đáp
{
    public partial class Bai19 : Form
    {
        public Bai19()
        {
            InitializeComponent();
            comboBox1.Items.Add("Details");
            comboBox1.Items.Add("LargeIcon");
            comboBox1.Items.Add("SmallIcon");
            comboBox1.Items.Add("List");
            listView1.View = View.Details;
            listView1.Columns.Add("Họ đệm", 190);
            listView1.Columns.Add("Tên", 100);
            listView1.Columns.Add("Điện thoại", 190);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string hoDem = txtHodem.Text;
            string ten = txtTen.Text;
            string soDienThoai = txtDienthoai.Text;

            if (!string.IsNullOrEmpty(hoDem) && !string.IsNullOrEmpty(ten) && !string.IsNullOrEmpty(soDienThoai))
            {
                ListViewItem item = new ListViewItem(hoDem, 0);
                item.SubItems.Add(ten);
                item.SubItems.Add(soDienThoai);
                listView1.Items.Add(item);
                txtHodem.Clear();
                txtTen.Clear();
                txtDienthoai.Clear();
            }
            else
            {
                MessageBox.Show("Hãy nhập đầy đủ thông tin Họ đệm, Tên và Số điện thoại.");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedView = comboBox1.SelectedItem.ToString();

            switch (selectedView)
            {
                case "Details":
                    listView1.View = View.Details;
                    break;
                case "LargeIcon":
                    listView1.View = View.LargeIcon;
                    break;
                case "SmallIcon":
                    listView1.View = View.SmallIcon;
                    break;
                case "List":
                    listView1.View = View.List;
                    break;
                default:
                    break;
            }
        }
    }
}
